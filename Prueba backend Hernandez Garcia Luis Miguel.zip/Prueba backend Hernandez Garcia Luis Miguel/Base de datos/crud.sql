-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-07-2022 a las 03:51:29
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `crud`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nombre` text NOT NULL,
  `apellidos` text NOT NULL,
  `telefono` text NOT NULL,
  `ciudad` text NOT NULL,
  `correo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `nombre`, `apellidos`, `telefono`, `ciudad`, `correo`) VALUES
(4, 'Baja Beach fest', 'Festival', '$2300 c/u', 'vie, 12 de ago de 2022 14:00vie, 12 de ago de 2022 | Papas & Beer (Papas & Beer Rosarito), Rosarito, BC', 'Mexico'),
(5, 'Ha*Ash', 'Conciert', '$2760 c/u', 'Ha ash & Maria Jose sáb, 23 de jul de 2022 21:00  sáb, 23 de jul de 2022 Fórum de Mundo Imperial, Acapulco, GRO', 'Acapulco'),
(6, 'Bring Me the Horizon', 'Conciert', '$864 c/u', 'Bring Me the Horizon mié, 26 de oct de 2022 17:00  mié, 26 de oct de 2022 Palacio de los Deportes, México, DF', 'Mexico DF'),
(7, 'Mentidrags', 'Musical', '$2300 c/u', 'MUSICALES  Boletos para Mentidrags en Teatro Mentiras Aldama', 'Mexico'),
(8, 'Magos joe y Moy', 'Teatro y culturales', '$445.75 c/u', 'Magos Joe y Moy dom, 7 de ago de 2022 13:00  dom, 7 de ago de 2022 Dejavú Night Hall, México, DF', 'Mexico');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
