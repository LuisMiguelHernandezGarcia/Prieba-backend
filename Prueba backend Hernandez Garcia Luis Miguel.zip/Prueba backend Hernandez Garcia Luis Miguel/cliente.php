<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1><Center>Bienvenido!!</Center></h1>
    <?php
    include("CRUDC/index.php");
    ?>
    <a href="Return.php" class="btn btn-danger"><span class="glyphicon glyphicon-log-out"></span>Volver al inicio</a>
</body>
</html>